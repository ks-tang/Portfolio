var searchData=
[
  ['headlocation_16',['headLocation',['../structSnake.html#a78705c7b8c6d515c8f4efb0679e7eeba',1,'Snake']]]
];
