var searchData=
[
  ['direction_55',['direction',['../structSnake.html#aca9c4b100fda1829b3f2ad0a8d688b6a',1,'Snake']]]
];
