var searchData=
[
  ['body_1',['body',['../structSnake.html#a03fe52ed9c27885e81bb827618244566',1,'Snake']]],
  ['body_5flength_2',['body_length',['../structSnake.html#a3506275396edc4d02c4ecb66cf51212c',1,'Snake']]]
];
