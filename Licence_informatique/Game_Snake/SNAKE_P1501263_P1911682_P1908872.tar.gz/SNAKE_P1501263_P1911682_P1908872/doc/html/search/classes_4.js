var searchData=
[
  ['snake_35',['Snake',['../structSnake.html',1,'']]],
  ['speeddown_36',['SpeedDown',['../structSpeedDown.html',1,'']]]
];
