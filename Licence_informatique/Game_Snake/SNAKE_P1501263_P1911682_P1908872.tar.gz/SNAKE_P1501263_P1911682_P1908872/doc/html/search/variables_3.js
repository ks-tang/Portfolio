var searchData=
[
  ['surfaceapple_57',['SurfaceApple',['../structApple.html#a56fb5a6cd176b55be9fac1234b30cf54',1,'Apple']]],
  ['surfacepoison_58',['SurfacePoison',['../structPoison.html#a6469416041b771c709952f695b478749',1,'Poison']]],
  ['surfacereduce_59',['SurfaceReduce',['../structReducer.html#aeb51857715f4b0a3d82e366cef514fc9',1,'Reducer']]],
  ['surfaceslow_60',['SurfaceSlow',['../structSpeedDown.html#a72a7e81b917c88bd9673b6b72cbdfddc',1,'SpeedDown']]]
];
