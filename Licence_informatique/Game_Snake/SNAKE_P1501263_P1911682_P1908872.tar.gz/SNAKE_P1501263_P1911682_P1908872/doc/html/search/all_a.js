var searchData=
[
  ['time_26',['time',['../structSnake.html#abc90f20938a9174165e1fe4a89e843f2',1,'Snake']]]
];
