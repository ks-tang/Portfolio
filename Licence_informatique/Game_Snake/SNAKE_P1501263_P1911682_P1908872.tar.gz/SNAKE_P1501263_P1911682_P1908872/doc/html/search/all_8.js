var searchData=
[
  ['reducer_18',['Reducer',['../structReducer.html',1,'']]],
  ['run_19',['run',['../classGame.html#a1ab78f5ed0d5ea879157357cf2fb2afa',1,'Game']]]
];
