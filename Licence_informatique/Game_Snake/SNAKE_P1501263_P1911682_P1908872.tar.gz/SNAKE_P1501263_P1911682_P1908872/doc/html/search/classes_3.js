var searchData=
[
  ['reducer_34',['Reducer',['../structReducer.html',1,'']]]
];
