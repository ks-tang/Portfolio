var searchData=
[
  ['eatapple_41',['eatApple',['../structSnake.html#aab7c16e6ef20635ecadfe4a9d7daedd0',1,'Snake']]],
  ['eatpoison_42',['eatPoison',['../structSnake.html#a0c3ac372f915c8a16c5b4585bdc6f9d6',1,'Snake']]],
  ['eatreducer_43',['eatReducer',['../structSnake.html#a1733dfb4e3ce8d0b934b29f220d5ff4d',1,'Snake']]],
  ['eatspeeddown_44',['eatSpeedDown',['../structSnake.html#a4571e95ff4ab6819033c35bb94d364c5',1,'Snake']]]
];
