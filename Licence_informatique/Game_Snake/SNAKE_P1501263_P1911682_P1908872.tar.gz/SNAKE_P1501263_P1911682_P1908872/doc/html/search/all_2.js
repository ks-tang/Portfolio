var searchData=
[
  ['checkcollision_3',['checkCollision',['../structSnake.html#ac31845fa6830b6bba11cc7ed36e9ea74',1,'Snake']]],
  ['checklimits_4',['checkLimits',['../structSnake.html#a0edc742976cc101b0cd1c73fd267b611',1,'Snake']]]
];
