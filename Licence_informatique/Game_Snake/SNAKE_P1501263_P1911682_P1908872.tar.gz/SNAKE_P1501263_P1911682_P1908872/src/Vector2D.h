#ifndef VECTOR2D
#define VECTOR2D

/*! 
** Structure Vector2D
*/
struct Vector2D
{
    ///Position 2D x et y
    int x, y;

    

};


#endif
